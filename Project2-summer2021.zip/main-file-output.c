#include<stdio.h>
#include<string.h>

int main() {
    FILE * fPtr;  // Pointer to a file
    
    int a=4;
    double n=4.567;
    char str[]="EGN 3211 class!!!";
    
    // Opoening the file in "w" (write) mode. An error is displayed if the file
    // couldn't be opened (file pointer=NULL)
    // Warning: if a file of the same name exists, it's replaced with the new file
    if( (fPtr = fopen("myfile.txt", "w")) == NULL) {
        printf("File could not be opened!... Exiting program.\n");
        system("PAUSE");
        return 1;
    }
    
    // Printing to the file
    // Use fprintf which has similar format to printf (it takes the file pointer
    // as the 1st parameter)
    fprintf(fPtr, "Printing starts...\n");
    
    fprintf(fPtr, "a = %d\n", a);
    fprintf(fPtr, "n = %.4lf\n", n);
    fprintf(fPtr, "%s\n", str);
    
 

    
    // Closing the file
    fclose(fPtr);
    
    printf("\n");
    system("PAUSE");
    return 0;    
}
